#Sequence 1
#Finn Thorley
#17/08/2021
#Version 1 
#This Memory Quiz is for people who want to learn Te Reo

import os
import time

def reply():
  print("Ok have a good day.")
  time.sleep(2)
  os.system('clear')
  quit()


def yes_no(question):
    valid = False
    while not valid:
     response = input (question) .lower()
    
    
     if response == "yes" or response == "y":
       response = "yes"
       return response
 
     elif response == "no" or response == "n":
       response = "no"
       return response

     else:
       print("Please answer seriously.")
       print()

def level(question):
    valid = False
    while not valid:
     response = input (question).lower()
    
    
     if response == "beginner" or response == "b":
       response = "beginner"
       return response
 
     elif response == "intermediate" or response == "i":
       response = "intermediate"
       return response

     if response == "advanced" or response == "a":
      response == "advanced"
      return response

     else:
       print("Please answer seriously.")
       print()

#SEQUENCE 3
#Finn Thorley
#17/08/2021
#Version 3
#This Memory Quiz is for people who want to learn Te Reo

def beginner():
  print()
  print("This is a memory quiz, you will have to remember the words, then type them out in Te Reo.")
  print()
  print("Remember to read the english translation.")
  print()
  print("Hello(Kia Ora)")
  print()
  print("Love(Aroha)")
  print()
  print("Family(Whanau)")
  print()
  print("Awa(River)")
  print()
  print("Iwi(Tribe)")
  
  print()
  play = yes_no ("would you like to start ")
  if play == "no" or play == "n":
    reply()
    print()
  print()
  time.sleep(3)
  os.system('clear')

  print("Ok let's begin!")

  print("What is Hello in Te Reo?")
  answer = input()
  

  if answer == "Kia Ora" or answer == "kia ora":
    print("Nice one!")
    
  else:
    print("Unlucky the correct answer was Kia Ora.")
    
  print("What is love in Te Reo?")
  answer = input()

  if answer == "Aroha" or answer == "aroha":
      print("Good job")

  else:
    print("Unlucky the correct answer was Aroha.")

  print("What is Family in Te Reo?")
  answer = input()

  if answer == "Whanau" or answer == "whanau":
      print("Solid")

  else: 
      print("Unlcuky the correct answer was Whanau.")

  print("What is River in Te Reo?")
  answer = input()

  if answer == "Awa" or answer == "awa":
    print("Too good")

  else:
    print("Unlucky the correct answer was Awa.")

  print("What is Tribe in Te Reo?")
  answer = input()

  if answer == "Iwi" or answer == "iwi":
    print("Good stuff")

  else:
    print("Unlucky the correct answer was Iwi.")

    print("***Congrats you have completed the Beginner Test***")
    time.sleep(4)
    print()
    play = yes_no("Would you like to try another level? ")

    if play == "no" or play == "n":
      reply()

    play = level ("Beginner, Intermediate, Advanced? ")
    print()
    print()

    if play == "beginner" or play == "b":
      beginner()
 
    elif play == "intermediate" or play == "i":
      intermediate()

    if play == "advanced" or play == "a":
      advanced()

#SEQUENCE 4
#Finn Thorley 
#17/08/2021
#Version 4
#This Memory quiz is for people that want to learn Te Reo


def intermediate():
  print()
  print("This is a memory quiz, you will have to remember the words, then type them out in Te Reo.")
  print()
  print("Children(Tamariki)")
  print()
  print("Boy(Tama)")
  print()
  print("School(Kura)")
  print()
  print("Woman(Wahine)")
  print()
  print("Land(Whenua)")
  os.system('clear')

  play = yes_no ("Would you like to start ")
  if play == "no" or play == "n":
    reply()
    print()
  print()
  print("Ok let's begin!")
  time.sleep(3)

  print("What is Children in Te Reo?")
  answer = input()

  if answer == "Tamariki" or answer == "tamariki":
     print("You got it!")

  else:
    print("Unlucky the correct answer was Tamariki.")

  print("What is boy in Te Reo?")
  answer = input()

  if answer == "Tama" or answer == "tama":
      print("Nice one!")

  else:
    print("Unlucky the correct answer was Tama.")

  print("What is School in Te Reo?")
  answer = input()

  if answer == "Kura" or answer == "kura":
      print("Ka Pai")
  
  else:
    print("Unlucky the correct answer was Kura.")

  print("What is Woman in Te Reo?")
  answer = input()

  if answer == "Wahine" or answer == "wahine":
      print("Nice")

  else:
    print("Unlucky the correct answer was Wahine.")

  print("What is land in Te Reo?")
  answer = input()

  if answer == "Whenua" or answer == "whenua":
    print("Good stuff")

  else:
    print("Unlucky the correct answer was Whenua.")

    print("***Congrats you have completed the Intermediate Test***")
    time.sleep(4)
    print()
    play = yes_no("Would you like to try another level? ")

    if play == "no" or play == "n":
      reply()

    play = level ("Beginner, Intermediate, Advanced? ")
    print()
    print()

    if play == "beginner" or play == "b":
      beginner()
 
    elif play == "intermediate" or play == "i":
      intermediate()

    if play == "advanced" or play == "a":
      advanced()

#SEQUENCE 5
#Finn Thorley
#17/08/2021
#Version 5
#This Memory Quiz is for people who want to learn Te Reo

def advanced():
  print()
  print("This is a memory quiz, you will have to remember the words, then type them out in Te Reo.")
  print()
  print("Respect(Manaakitanga)")
  print()
  print("Visitors(Manuhiri)")
  print()
  print("Funeral(Tangi)")
  print()
  print("Island(Motu)")
  print()
  print("Hamilton(Kirikiriroa)")
  print()

  play = yes_no ("Would you like to start now?")
  if play == "no" or play == "n":
    reply()
    print()
  print()
  print("Ok let's begin!")
  time.sleep(3)

  print("What's respect in Te Reo?")
  answer = input()

  if answer == "Manaakitanga" or answer == "manaakitanga":
    print("Nice!")

  else:
    print("Unlucky the correct answer was Manaakitanga")

  print("What is visitors in Te Reo?")
  answer = input()

  if answer == "Manuhiri" or answer == "manuhiri":
    print("Good stuff")

  else:
    print("Unlucky the correct answer was Manuhiri.")

  print("What is Funeral in Te Reo?")
  answer = input()

  if answer == "Tangi" or answer == "tangi":
    print("Correct!")

  else:
    print("Unlucky the correct answer was Tangi.")

  print("What is Island in Te Reo?")
  answer = input()

  if answer == "Motu" or answer == "motu":
    print("Solid")

  else:
    print("Unlucky the correct answer was Motu.")

  print("What is Hamilton in Te Reo?")
  answer = input()

  if answer == "Kirikiriroa" or answer == "Kirikirikoa":
    print("Good work")

  else:
    print("Unlucky the correct answer was Kirikiriroa")

    print("***Congrats you have completed the Advanced Test***")
    time.sleep(4)
    print()
    play = yes_no("Would you like to try another level? ")

    if play == "no" or play == "n":
      reply()

    play = level ("Beginner, Intermediate, Advanced? ")
    print()
    print()

    if play == "beginner" or play == "b":
      beginner()
 
    elif play == "intermediate" or play == "i":
      intermediate()

    if play == "advanced" or play == "a":
      advanced()


#Sequence 2
#Finn Thorley
#17/08/2021
#Version 2
#This Memory Quiz is for people who want to learn Te Reo

#Greeting the Users
print ("Welcome to this quiz")
print ("What is your name?")

name = input()

print ("Kia Ora " + name + ",")

want_play = yes_no ("Would you like to play? ")

if want_play == "no" or want_play == "n":
  reply()
print()

print ("What level do you think you're at with Te Reo?")

game = level ("Beginner, Intermediate, Advanced: ")
time.sleep(3)


if game == "beginner" or game == "b":
  beginner()
  

elif game == "intermediate" or game == "i":
  intermediate()

if game == "advanced" or game == "a":
  advanced()









